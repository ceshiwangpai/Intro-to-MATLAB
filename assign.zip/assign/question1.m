


%%%%%%%  Codes for Question 1A  %%%%%%
syms x 
f= (1-cos(6*x))/(5*x);

A = limit(f,x,0);


%%%%%%  Codes for Question 1B  %%%%%%

syms x
f= (2+sqrt(x))/(x+1);
B= int(f,x,1,10);

B1=double(B);


%%%%%%  Codes for Question 1C %%%%%%

syms x y

f= y*x^3+2*x*y;

f1=int(f,x,1,y^2);

D= int(f1,y,0,1);

D1=double(D);

%%%%%%  Codes for Question 1D %%%%%%

syms x

f=exp(5*x)*sin(x+2);

D=diff(f,x);