
%%%%% codes for Q5
clc
syms u(t) t

%%%%  assign value to variables
m=4;
c=12;
k=1100;

%%%%% equation formulation
eqn = m*diff(u,t,2)+c*diff(u,t)+k*u==0;
Du=diff(u,t);
cond = [u(0)==0.5,Du(0)==0];

%%%%%% solve the equation
u=dsolve(eqn,cond);


disp('u=')
disp(u)

%%%%%%%%  plot

t=0:0.01:4;
k1=sqrt(1091)/2;
k2=3*sqrt(1091);
u1= 1/2182*exp(-1.5*t).*(cos(k1*t)+k2*sin(k1*t));


plot(t,u1);

