% function Hilbert1
% Hilbert space filling curve
clc,close all      %%%  correct 'cls' to 'clc'
figure('position',[200,200,1200,800],'color',[1 1 1])   %%%%  correct 'colour' to 'color'
for I=1:6
    [x,y]=Hilbert2(I);
    subplot(3,2,I)
    colour = ['c','b','g','m','r','k'];
    plot(x,y,colour(I))
    axis off
end

    function [x,y] = Hilbert2(n)
        if n<=0
            x=0;
 y=0;
        else
            [xo,yo]=Hilbert2(n-1);
            z=0.4;
            x=z*[-z+yo -z+xo z+xo  z-yo];
            y=z*[-z+xo  z+yo z+yo -z-xo];
        end
    end
end




