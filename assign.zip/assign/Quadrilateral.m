
%%%% NOte:  P1~P4 are the four vertices of the quadrilateral.
%%%            P1~P4 each is a 1 by 2 array

function [A P C]= Quadrilateral( P1,P2,P3,P4)

warning off

coor=[P1;P2;P3;P4];
X=coor(:,1)';
Y=coor(:,2)';
quad= polyshape(X,Y);

num_Vertex= size(quad.Vertices,1);

if num_Vertex<4  %%%%  decide if 2 or more vertices are collinear
    
    disp('Three or more vertices are collinear, please correct the input data ');

else
    %%%%   extract the vertices
%     x= quad.Vertices(:,1);
%     y= quad.Vertices(:,2);  
    
    %%%%% plot the quad
    plot(quad);
    
    %%%  calculate the area
    A=area(quad);
    
    P=perimeter(quad);
    
    [C1,C2]=centroid(quad);
    
  C=[C1,C2];
    
end

end