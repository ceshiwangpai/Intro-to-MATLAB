    function [x,y] = Hilbert2(n)
        if n<=0
            x=0;
            y=0;
        else
            [xo,yo]=Hilbert2(n-1);
            z=0.4;
            x=z*[-z+yo -z+xo z+xo  z-yo];
            y=z*[-z+xo  z+yo z+yo -z-xo];
        end
    end