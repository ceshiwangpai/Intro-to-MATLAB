function Hilbert1
% Hilbert space filling curve
clc,close all      %%%  correct 'cls' to 'clc'
figure('position',[200,200,1200,800],'color',[1 1 1])   %%%%  correct 'colour' to 'color'
for I=1:6
    [x,y]=Hilbert2(I);
    subplot(3,2,I)
    colour = ['c','b','g','m','r','k'];
    plot(x,y,colour(I))
    axis off
end


end




