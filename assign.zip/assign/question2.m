

%%% Note : The spreadsheet that contains the original data is named as
%%% orginaldata.xlsx and is kept under a file folder.
%%%  The path refers to the folder where the spreadsheet is kept.

clear

%%%%  import the data from the spreadsheet and convert the table to an array
path='C:\Users\13692708\OneDrive - UTS\Documents\MATLAB\assign\';
data= readtable([path,'orginaldata.xlsx'], ...
                'Sheet','Sheet1');

data1=table2array(data);

%%%%%  find and delete the Nan elements
Indmat= isnan(data1);
data1(Indmat)=[];
data1=reshape(data1,52,[]);


%%%%% calculate the mean and std of P,CF, CP
P= data1(:,1);
mean_P=mean(P);
std_P=std(P);

CF= data1(:,2);
mean_CF= mean(CF);
std_CF=std(CF);


CP= data1(:,3);
mean_CP= mean(CP);
std_CP=std(CP);


